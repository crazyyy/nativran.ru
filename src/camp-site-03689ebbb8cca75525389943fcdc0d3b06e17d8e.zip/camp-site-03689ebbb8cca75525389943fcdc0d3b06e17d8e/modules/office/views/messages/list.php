<?
use yii\helpers\Url;

$this->title = 'Личный кабинет';

$ca = Yii::$app->controller->id . '/' . Yii::$app->controller->action->id;
$act[$ca] = 'class="active"';
?>
<div class="layout-container">

</div>
