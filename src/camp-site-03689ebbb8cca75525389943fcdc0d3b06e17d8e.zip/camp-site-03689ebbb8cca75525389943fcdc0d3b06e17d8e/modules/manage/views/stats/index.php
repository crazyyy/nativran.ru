<?php
/** @var $this \yii\web\View */

$this->title = 'В разработке, нужно согласование, какие данные показывать';
$this->params['breadcrumbs'] = [$this->title];