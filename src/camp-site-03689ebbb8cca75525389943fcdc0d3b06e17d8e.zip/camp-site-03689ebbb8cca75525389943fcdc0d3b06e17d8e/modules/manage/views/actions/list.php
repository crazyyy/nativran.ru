<?php
/** @var $this \yii\web\View */

$this->title = 'В разработке';
$this->params['breadcrumbs'] = [$this->title];