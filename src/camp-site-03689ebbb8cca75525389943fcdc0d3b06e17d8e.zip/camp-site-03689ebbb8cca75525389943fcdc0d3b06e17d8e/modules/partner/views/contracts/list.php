<?
use yii\helpers\Url;

$this->title = \app\modules\partner\controllers\ContractsController::LIST_NAME;
$this->params['breadcrumbs'] = [$this->title];