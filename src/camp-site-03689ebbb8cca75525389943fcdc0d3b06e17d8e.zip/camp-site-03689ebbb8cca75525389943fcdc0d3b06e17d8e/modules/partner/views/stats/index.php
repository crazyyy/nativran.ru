<?
use yii\helpers\Url;

$this->title = \app\modules\partner\controllers\StatsController::INDEX_NAME;
$this->params['breadcrumbs'] = [$this->title];