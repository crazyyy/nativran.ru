<?
use yii\helpers\Url;

$this->title = \app\modules\partner\controllers\FinancesController::LIST_NAME;
$this->params['breadcrumbs'] = [$this->title];