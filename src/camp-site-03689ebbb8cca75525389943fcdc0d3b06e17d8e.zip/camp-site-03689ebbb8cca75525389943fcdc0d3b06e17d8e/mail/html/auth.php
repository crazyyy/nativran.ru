<?
/** @var string $content */
?>
<?= $content ?>