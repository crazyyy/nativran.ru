<div class="pagination">
  <!-- noindex --><?php html5wp_pagination(); ?><!-- /noindex -->
</div><!-- /pagination -->
