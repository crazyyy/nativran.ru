<form class="search" method="get" action="<?php echo home_url(); ?>" role="search">
  <input class="search-input" type="search" name="s" placeholder="<?php _e( 'To search, type and hit enter.', 'wpeasy' ); ?>">
  <button class="search-submit" type="submit" role="button"><i class="fa fa-search" aria-hidden="true"></i></button>
</form><!-- /search -->
